%% exp 1: plot the pmf of levels 
R = 8;
blklen = 2^12;
ntries = 2^12;
abscissa = (0:(2^(R-1)-1))/2^(R-1);
[~,pdf,pdfth] = cptcq(2,blklen,R,ntries,'gau');
figure(1);
plot(abscissa,pdf); hold on;
plot(abscissa,pdfth);
[~,pdf,pdfth] = cptcq(2,blklen,R,ntries,'lap');
plot(abscissa,pdf);
plot(abscissa,pdfth);
grid on; axis tight;
xlabel({'$l/2^{R_{\rm cp}-1}$'}, 'interpreter', 'latex');
legend({'$f_L(l)$, Gau', '$f_Y(y)$, Gau', '$f_L(l)$, Lap', '$f_Y(y)$, Lap'}, 'interpreter', 'latex');
title({'$4$ states, $R_{\rm cp}=8$'}, 'interpreter', 'latex'); % to change figure title here
set(gca,'FontSize',16);

%% exp 2: snr loss vs. number of states
R = 8;
blklen = 2^12;
ntries = 2^12;
snrlossGau = zeros(1,5);
snrlossLap = zeros(1,5);
snrlossGau(1) = cptcq(1,blklen,R,ntries,'gau');    
snrlossLap(1) = cptcq(1,blklen,R,ntries,'lap');    
snrlossGau(2) = cptcq(2,blklen,R,ntries,'gau');    
snrlossLap(2) = cptcq(2,blklen,R,ntries,'lap');
snrlossGau(3) = cptcq(3,blklen,R,ntries,'gau');    
snrlossLap(3) = cptcq(3,blklen,R,ntries,'lap');    
snrlossGau(4) = cptcq(4,blklen,R,ntries,'gau');    
snrlossLap(4) = cptcq(4,blklen,R,ntries,'lap');
snrlossGau(5) = cptcq(8,blklen,R,ntries,'gau');    
snrlossLap(5) = cptcq(8,blklen,R,ntries,'lap');    
plot([1,2,3,4,8],snrlossGau,'-*'); hold on; 
plot([1,2,3,4,8],snrlossLap,'-o');
plot([1,2,3,4,8],1.533*ones(1,5),'b--'); 
plot([1,2,3,4,8],1.3326*ones(1,5),'r--');
grid on; axis tight;
title({'$R_{\rm cp}=8$'}, 'interpreter', 'latex'); % to change figure title here
xlabel({'log of the num of trellis states'}, 'interpreter', 'latex');
ylabel({'SNR Loss (dB)'}, 'interpreter', 'latex');
legend({'${\rm SNR}-{\rm SNR}_{\rm cptcq}$, Gau', '${\rm SNR}-{\rm SNR}_{\rm cptcq}$, Lap', '${\rm SNR}-{\rm SNR}_{\rm sq}$, Gau', '${\rm SNR}-{\rm SNR}_{\rm sq}$, Lap'}, 'interpreter', 'latex');
set(gca,'FontSize',16);