function [snrloss,pdf,pdfth] = cptcq(memlen,n,R,ntry,model)
%% This file was written by Yong Fang (fy@chd.edu.cn, yfang79@gmail.com, and fangyong@nwafu.edu.cn)
% You can use it, but you can NOT remove these two lines.
% memlen: memory size for trellis
% n: block length
% R: rate (bits/sample)
% ntry: number of tests for each data point
% model: source model ('gau' or 'lap')

%% generate a trellis from a polynomial
if memlen==1
    t = poly2trellis(memlen+1,[2,3]);
elseif memlen==2
    t = poly2trellis(memlen+1,[5,7]);
elseif memlen==3
    t = poly2trellis(memlen+1,[15,17]);
elseif memlen==4
    t = poly2trellis(memlen+1,[23,35]);
elseif memlen==5
    t = poly2trellis(memlen+1,[45,67]);
elseif memlen==6
    t = poly2trellis(memlen+1,[117,147]);
elseif memlen==8
    t = poly2trellis(memlen+1,[777,435]);
else
    error('Unsupported memory length!');
end
% The trellis must be modified before use.
nextStates = t.nextStates + 1;
nextOutput = t.outputs + 1;
nextStates(2:2:2^memlen,:) = fliplr(nextStates(2:2:2^memlen,:));  % flip even rows
nextOutput = sort(nextOutput,2);
nextOutput(nextOutput>2) = 7 - nextOutput(nextOutput>2);% Gray code
prevStates = nextStates;
prevOutput = nextOutput;
for s=1:2^memlen
    prevStates(s,:) = [find(nextStates(:,1)==s), find(nextStates(:,2)==s)];
    prevOutput(s,:) = [nextOutput(prevStates(s,1),1), nextOutput(prevStates(s,2),2)];
end

%% some statistics
mex = 0; % mean quantization error of x
mey = 0; % mean quantization error of y
pmf = zeros(1,2^(R-1)); % distribution of levels
bias = 0;% bias probability of branches
usqs = zeros(1,4);

% %% multicores
% cls = parcluster;
% pool = gcp;
% if isempty(pool)
%     pool = parpool(cls.NumWorkers);
% end
% nw = pool.NumWorkers;   % number of workers

%% shifts for 4 USQers
shift = ((1:4)-0.5)/2^(R+1);
%% run a lot of tests
for itry=1:ntry
    %% generate x and map it to y with a compander
    if strcmp(model,'gau')
        x = randn(1,n); % samples drawn from standard Gaussian distribution
        y = erfc(-x/sqrt(6))/2;
    elseif strcmp(model,'lap')
        x = log(rand(1,n)) - log(rand(1,n)); % samples drawn from standard Laplacian distribution
        y = 0.5*exp(-abs(x)/2);
        y(x>0) = 1 - y(x>0);
    else
        error('Unsupported source model!');
    end
        
    %% 4 USQers with 4 sub-codebooks
    l = zeros(4,n); % indices of codewords in each sub-codebook
    c = zeros(4,n); % codewords in each sub-codebook
    e = zeros(4,n); % quantization errors
    for o=1:4       % for each sub-codebook
        l(o,:) = max(0,min(round((y-shift(o))*2^(R-1)),2^(R-1)-1));
        c(o,:) = l(o,:)/2^(R-1) + shift(o);
        if strcmp(model,'gau')
            e(o,:) = (y-c(o,:)).^2;
        elseif strcmp(model,'lap')
            e(o,:) = abs(y-c(o,:));
        else
            error('Unsupported source model!');
        end
    end
    
    %% run the Viterbi algorithm
    cost = inf(2^memlen,n+1);
    cost(1,1) = 0; % the graph always begins from zero state 
    edge = zeros(2^memlen,n);
    for i=1:n
        for s=1:2^memlen
            [cost(s,i+1),edge(s,i)] = min(cost(prevStates(s,:),i) + e(prevOutput(s,:),i));
        end
    end
    [mcst,s] = min(cost(:,n+1));% the best path with minimum cost ends at state s.
    mey = mey + mcst/n;

    %% trace back
    input = repmat(edge(s,n),1,n); % 1 bit per sample
    level = repmat(l(prevOutput(s,input(n)),n),1,n); % (R-1) bits per sample
    for i=(n-1):-1:1
        s = prevStates(s,input(i+1));
        input(i) = edge(s,i); 
        level(i) = l(prevOutput(s,input(i)),i);
    end
    
    %% input and level are sent. make some statistics
    for i=1:2^(R-1)
        pmf(i) = pmf(i) + nnz(level==(i-1));
    end
    bias = bias + sum(input==2);
    
    %% dequantization
    output = ones(1,n);
    states = ones(1,n+1);% the graph always begins from zero state
    for i=1:n
        output(i) = nextOutput(states(i),input(i));
        states(i+1) = nextStates(states(i),input(i));% transfer to next state
    end    
    for i=1:4
        usqs(i) = usqs(i) + nnz(output==i); 
    end
    yr = level/2^(R-1) + shift(output);    
    % correctness verification
    if strcmp(model,'gau')
        assert(mse(yr-y)==mcst/n);  % the deQer's output should match the Qer's local output exactly.
    elseif strcmp(model,'lap')
        assert(mae(yr-y)==mcst/n);  % the deQer's output should match the Qer's local output exactly.
    else
        error('Unsupported source model!');
    end
    
    % map yr back to xr
    if strcmp(model,'gau')
        xr = -sqrt(6)*erfcinv(2*yr);
        mex = mex + mse(xr-x);
    elseif strcmp(model,'lap')
        xr = 2*log(2*yr);
        xr(yr>0.5) = -2*log(2*(1-yr(yr>0.5)));
        mex = mex + mae(xr-x);        
    else
        error('Unsupported source model!');
    end
end
assert(sum(pmf)==(ntry*n));% correctness verification

%% show the bias probability of USQer indices
disp('Bias Probability of Branch Bits, equal to 1/2 in theory');
disp(bias/(ntry*n));
disp('Distribution of USQers, equal to 1/4 in theory');
disp(usqs/sum(usqs));

%% get the experimental and theoretical pdf of levels, and rate saving of levels by entropy coding
pmf = pmf/(ntry*n);
pdf = pmf*2^(R-1);
abscissa = (0:(2^(R-1)-1))/2^(R-1) + 2^(-R);
if strcmp(model,'gau')
    pdfth = sqrt(3)*exp(-2*erfcinv(2*abscissa).^2);
elseif strcmp(model,'lap')
    pdfth = 4*abscissa;
    pdfth((2^(R-2)+1):2^(R-1)) = pdfth((2^(R-2)+1):2^(R-1)) - 8*abscissa(1:2^(R-2));
else
    error('Unsupported model!');
end
pmfth = pdfth/2^(R-1); 
r = 1-sum(pmf.*log2(pmfth));
disp('-h(Y), equal to 0.3116 (Gau) or 0.2787 (Lap) in theory');
disp(R-r);

%% show distortions and SNR loss
if strcmp(model,'gau')
    disp('D_X/(6*sqrt(3)*pi*D_Y), equal to 1 in theory');
    disp(mex/(6*sqrt(3)*pi*mey));
    disp('Reductions of D_Y and D_X by TCQer');
    disp({2^(-2*R)/12-mey/ntry, 6*sqrt(3)*pi*(2^(-2*R)/12)-mex/ntry});
    snrloss = (R-0.3116)*20*log10(2)+10*log10(mex/ntry);
elseif strcmp(model,'lap')
    disp('D_X/(8*D_Y) (equal to 1 in theory)');
    disp(mex/(8*mey));
    disp('Reductions of D_Y and D_X by TCQer');
    disp({2^(-R)/4-mey/ntry, 8*(2^(-R)/4)-mex/ntry});
    snrloss = (R-0.2787)*10*log10(2)+10*log10(mex/ntry);
else
    error('Unsupported model!');
end
disp('SNR Loss');
disp(snrloss);